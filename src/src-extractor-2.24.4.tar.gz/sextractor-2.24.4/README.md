# SExtractor

[![Build Status](https://travis-ci.org/astromatic/sextractor.svg?branch=master)](https://travis-ci.org/astromatic/sextractor)
[![Coverity Scan Build Status](https://scan.coverity.com/projects/sextractor/badge.svg)](https://scan.coverity.com/projects/sextractor "Coverity Badge")
[![Documentation Status](https://readthedocs.org/projects/sextractor/badge/?version=latest)](http://sextractor.readthedocs.io/en/latest/?badge=latest)

[SExtractor] stands for ``Source Extractor'': a software for extracting catalogs of sources from astronomical images.

Check out the on-line [documentation], the [official web page], and the [user forum].

[SExtractor]: http://astromatic.net/software/sextractor
[documentation]: http://sextractor.readthedocs.org
[official web page]: http://astromatic.net/software/sextractor
[user forum]: http://astromatic.net/forum/forumdisplay.php?fid=4

